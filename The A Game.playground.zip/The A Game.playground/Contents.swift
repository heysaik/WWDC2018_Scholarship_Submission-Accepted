//: Rock Paper Scissors- The Classic Game With Expansion Beginning In The 1700s
//:
//: Augmented Reality- The Breakthrough Of Our Reality With Roots From The 1900s
//:
//: Machine Learning- The Fascinating Field Of Computer Science Starting In The 1950s
//:
//: I wonder what happens when we mash them together? 🤔
import UIKit
import Foundation
import AVFoundation
import ARKit
import Vision
import SceneKit
import CoreML
import PlaygroundSupport

func createGradient(colors: [CGColor], startPoint: CGPoint, endPoint: CGPoint) -> CAGradientLayer {
    let gradient = CAGradientLayer()
    gradient.colors = colors
    gradient.startPoint = startPoint
    gradient.endPoint = endPoint
    return gradient
}

func createLabel(title: String, font: UIFont, alpha: CGFloat, fontColor: UIColor, textAlignment: NSTextAlignment) -> UILabel {
    let label = UILabel(frame: .zero)
    label.numberOfLines = 0
    label.text = title
    label.font = font
    label.alpha = alpha
    label.textColor = fontColor
    label.textAlignment = textAlignment
    return label
}

func createButton(title: String, font: UIFont, alpha: CGFloat, fontColor: UIColor, textAlignment: NSTextAlignment) -> UIButton {
    let button = UIButton(frame: .zero)
    button.showsTouchWhenHighlighted = true
    button.setTitle(title, for: .normal)
    button.alpha = alpha
    button.titleLabel?.font = font
    button.titleLabel?.textAlignment = textAlignment
    return button
}

func delay(_ seconds: Double, completion: @escaping () -> ()) {
    DispatchQueue.main.asyncAfter(deadline: .now() + seconds) {
        completion()
    }
}

class MenuViewController: UIViewController {
    let gameTitle = createLabel(title: "Rock, Paper, Scissors", font: .systemFont(ofSize: 40, weight: .heavy), alpha: 0.0, fontColor: .white, textAlignment: .center)
    let subtitle = createLabel(title: "The Classic Game With A Modern Twist", font: .systemFont(ofSize: 20, weight: .semibold), alpha: 0.0, fontColor: .white, textAlignment: .center)
    let msg = createLabel(title: "Psst! Tap on each one of us!", font: .systemFont(ofSize: 13, weight: .ultraLight), alpha: 0.0, fontColor: .white, textAlignment: .center)
    let rockDev = createButton(title: "✊", font: .systemFont(ofSize: 75), alpha: 0.0, fontColor: .white, textAlignment: .center)
    let scissorsAck = createButton(title: "✌️", font: .systemFont(ofSize: 75), alpha: 0.0, fontColor: .white, textAlignment: .center)
    let paperPlayground = createButton(title: "🖐", font: .systemFont(ofSize: 75), alpha: 0.0, fontColor: .white, textAlignment: .center)
    let playButton = createButton(title: "", font: .systemFont(ofSize: 75), alpha: 0.0, fontColor: .white, textAlignment: .center)
    let musicControl = createButton(title: "🔉", font: .systemFont(ofSize: 30), alpha: 0.0, fontColor: .white, textAlignment: .center)
    let future = createButton(title: "⭐️", font: .systemFont(ofSize: 30), alpha: 0.0, fontColor: .white, textAlignment: .center)
    var soundtrack: AVAudioPlayer?
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        gameTitle.frame = CGRect(x: 0, y: 50, width: self.view.frame.size.width, height: 65)
        subtitle.frame = CGRect(x: 0, y: self.gameTitle.frame.minY + 50, width: self.view.frame.size.width, height: 60)
        playButton.frame = CGRect(x: self.view.frame.midX - 125, y: self.view.frame.midY - 125, width: 250, height: 250)
        msg.frame = CGRect(x: 0, y: self.view.frame.maxY - 30, width: self.view.frame.width, height: 18)
        rockDev.frame = CGRect(x: self.view.frame.midX - 150, y: self.msg.frame.minY - 110, width: 100, height: 100)
        paperPlayground.frame = CGRect(x: self.view.frame.midX - 50, y: self.msg.frame.minY - 110, width: 100, height: 100)
        scissorsAck.frame = CGRect(x: self.view.frame.midX + 50, y: self.msg.frame.minY - 110, width: 100, height: 100)
        musicControl.frame = CGRect(x: self.view.frame.maxX - 50, y: self.view.frame.maxY - 50, width: 40, height: 40)
        future.frame = CGRect(x: self.view.frame.minX + 10, y: self.view.frame.maxY - 50, width: 40, height: 40)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        UIView.animate(withDuration: 1.0, delay: 0.0, options: [.autoreverse, .repeat, .allowUserInteraction], animations: {
            self.playButton.transform = CGAffineTransform(scaleX: 1.2, y: 1.2)
        }, completion: nil)
    }
    
    override public func viewDidLoad() {
        super.viewDidLoad()
        let gradient = createGradient(colors: [#colorLiteral(red: 0, green: 0.6470588235, blue: 1, alpha: 1).cgColor, #colorLiteral(red: 0, green: 0.2392156863, blue: 0.6745098039, alpha: 1).cgColor], startPoint: CGPoint(x: 1.0, y: 0.0), endPoint: CGPoint(x: 0.0, y: 1.0))
        gradient.frame = self.view.bounds
        self.view.layer.addSublayer(gradient)
        self.view.backgroundColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
        
        self.view.addSubview(gameTitle)
        self.view.addSubview(subtitle)
        self.view.addSubview(msg)
        rockDev.addTarget(self, action: #selector(self.aboutTheDev(sender:)), for: .touchUpInside)
        self.view.addSubview(rockDev)
        paperPlayground.addTarget(self, action: #selector(self.aboutThePlayground(sender:)), for: .touchUpInside)
        self.view.addSubview(paperPlayground)
        scissorsAck.addTarget(self, action: #selector(self.acknowledgements(sender:)), for: .touchUpInside)
        self.view.addSubview(scissorsAck)
        musicControl.addTarget(self, action: #selector(self.controlMusic(sender:)), for: .touchUpInside)
        self.view.addSubview(musicControl)
        future.addTarget(self, action: #selector(self.futureThoughts(sender:)), for: .touchUpInside)
        self.view.addSubview(future)
        
        playButton.backgroundColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
        playButton.layer.cornerRadius = 105
        playButton.addTarget(self, action: #selector(self.playGame(sender:)), for: .touchUpInside)
        playButton.setImage(#imageLiteral(resourceName: "Rocket.png"), for: .normal)
        self.view.addSubview(playButton)
        
        let path = Bundle.main.path(forResource: "Roshambeau.m4a", ofType: nil)!
        let url = URL(fileURLWithPath: path)
        dismiss(animated: true, completion: nil)
        do {
            soundtrack = try AVAudioPlayer(contentsOf: url)
            soundtrack?.numberOfLoops = 10
            soundtrack?.volume = 0.1
            soundtrack?.play()
        } catch {
            print("Uh-oh")
        }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        if UserDefaults.standard.bool(forKey: "initialAnimations") == nil {
            scissorsAck.alpha = 1.0
            rockDev.alpha = 1.0
            paperPlayground.alpha = 1.0
            msg.alpha = 1.0
            subtitle.alpha = 1.0
            gameTitle.alpha = 1.0
        } else {
            self.beginAnimations()
        }
    }
    
    @objc func aboutTheDev(sender: UIButton!) {
        let presentVC = DevViewController()
        presentVC.modalTransitionStyle = .flipHorizontal
        presentVC.modalPresentationStyle = .formSheet
        present(presentVC, animated: true, completion: nil)
        UserDefaults.standard.set(true, forKey: "initialAnimations")
    }
    
    @objc func aboutThePlayground(sender: UIButton!) {
        let presentVC = PlaygroundViewController()
        presentVC.modalTransitionStyle = .flipHorizontal
        presentVC.modalPresentationStyle = .formSheet
        self.present(presentVC, animated: true, completion: nil)
    }
    
    @objc func acknowledgements(sender: UIButton!) {
        let presentVC = AcknowledgementsViewController()
        presentVC.modalTransitionStyle = .flipHorizontal
        presentVC.modalPresentationStyle = .formSheet
        present(presentVC, animated: true, completion: nil)
    }
    
    @objc func controlMusic(sender: UIButton!) {
        if musicControl.titleLabel?.text == "🔉" {
            soundtrack?.volume = 0
            musicControl.setTitle("🔇", for: .normal)
        } else {
            soundtrack?.volume = 0.1
            musicControl.setTitle("🔉", for: .normal)
        }
    }
    
    @objc func futureThoughts(sender: UIButton!) {
        let presentVC = FutureViewController()
        presentVC.modalTransitionStyle = .flipHorizontal
        presentVC.modalPresentationStyle = .formSheet
        present(presentVC, animated: true, completion: nil)
    }
    
    @objc func playGame(sender: UIButton!) {
        let vc = GameViewController()
        vc.modalTransitionStyle = .crossDissolve
        present(vc, animated: true, completion: { 
            self.musicControl.alpha = 1.0
            self.msg.alpha = 1.0
            self.future.alpha = 1.0
        })
    }
    
    func beginAnimations() {
        let showTitle = UIViewPropertyAnimator(duration: 0.5, curve: .easeInOut) {
            self.gameTitle.frame = self.gameTitle.frame.offsetBy(dx: 0, dy: -30)
            self.subtitle.frame = self.subtitle.frame.offsetBy(dx: 0, dy: -30)
            self.gameTitle.alpha = 1.0
            self.subtitle.alpha = 1.0
        }
        
        let showButtons = UIViewPropertyAnimator(duration: 0.5, curve: .easeInOut) {
            self.rockDev.alpha = 1.0
            self.paperPlayground.alpha = 1.0
            self.playButton.alpha = 1.0
            self.scissorsAck.alpha = 1.0
        }
        showTitle.startAnimation(afterDelay: 0.5)
        showButtons.startAnimation(afterDelay: 1.5)
    }
    
}

class PageViewController: UIPageViewController, UIPageViewControllerDataSource, UIPageViewControllerDelegate {
    var pages = [UIViewController]()
    let pageControl = UIPageControl()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.dataSource = self
        self.delegate = self
        let initialPage = 0
        let page1 = PageOne()
        let page2 = PageTwo()
        let page3 = PageThree()
        
        self.pages.append(page1)
        self.pages.append(page2)
        self.pages.append(page3)
        setViewControllers([pages[initialPage]], direction: .forward, animated: true, completion: nil)
        
        self.pageControl.frame = CGRect()
        self.pageControl.currentPageIndicatorTintColor = .white
        self.pageControl.pageIndicatorTintColor = .darkGray
        self.pageControl.numberOfPages = self.pages.count
        self.pageControl.currentPage = initialPage
        self.view.addSubview(self.pageControl)
        
        self.pageControl.translatesAutoresizingMaskIntoConstraints = false
        self.pageControl.bottomAnchor.constraint(equalTo: self.view.bottomAnchor, constant: -5).isActive = true
        self.pageControl.widthAnchor.constraint(equalTo: self.view.widthAnchor, constant: -20).isActive = true
        self.pageControl.heightAnchor.constraint(equalToConstant: 20).isActive = true
        self.pageControl.centerXAnchor.constraint(equalTo: self.view.centerXAnchor).isActive = true
    }
    
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerBefore viewController: UIViewController) -> UIViewController? {
        if let viewControllerIndex = self.pages.index(of: viewController) {
            if viewControllerIndex == 0 {
                return self.pages.last
            } else {
                return self.pages[viewControllerIndex - 1]
            }
        }
        return nil
    }

    func pageViewController(_ pageViewController: UIPageViewController, viewControllerAfter viewController: UIViewController) -> UIViewController? {
        if let viewControllerIndex = self.pages.index(of: viewController) {
            if viewControllerIndex < self.pages.count - 1 {
                return self.pages[viewControllerIndex + 1]
            } else {
                return self.pages.first
            }
        }
        return nil
    }
    
    func pageViewController(_ pageViewController: UIPageViewController, didFinishAnimating finished: Bool, previousViewControllers: [UIViewController], transitionCompleted completed: Bool) {
        if let viewControllers = pageViewController.viewControllers {
            if let viewControllerIndex = self.pages.index(of: viewControllers[0]) {
                self.pageControl.currentPage = viewControllerIndex
            }
        }
    }
    
    override init(transitionStyle style: UIPageViewControllerTransitionStyle, navigationOrientation: UIPageViewControllerNavigationOrientation, options: [String : Any]? = nil) {
        super.init(transitionStyle: .scroll, navigationOrientation: .horizontal, options: options)
    }
    
    required init?(coder: NSCoder) {
        fatalError("oops")
    }
}

class PageOne: UIViewController {
    var titleLabel = createLabel(title: "How To Play", font: UIFont.systemFont(ofSize: 40, weight: .bold), alpha: 1.0, fontColor: #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0), textAlignment: .center)
    var stepOneLabel = createLabel(title: "1. Get Excited! You're about to witness an awesome fusion of the past and the future!", font: .systemFont(ofSize: 17, weight: .medium), alpha: 1.0, fontColor: .white, textAlignment: .left)
    var stepTwoLabel = createLabel(title: "2. Move your device, in landscape orientation, until the two cylinders appear. This will be used to keep track of the scores.", font: .systemFont(ofSize: 17, weight: .medium), alpha: 1.0, fontColor: .white, textAlignment: .left)
    var stepThreeLabel = createLabel(title: "3. Choose your symbol- Rock, Paper, or Scissors. Place it in front of the camera.", font: .systemFont(ofSize: 17, weight: .medium), alpha: 1.0, fontColor: .white, textAlignment: .left)
    var noteLabel = createLabel(title: "For Accuracy: Center your hand in the bottom half of the screen. Check to see that the background contrasts your hand. Make sure only your fingers are shown if choosing Paper or Scissors, and your entire hand if choosing Rock.", font: UIFont.italicSystemFont(ofSize: 17), alpha: 1.0, fontColor: .white, textAlignment: .left)
    var stepFourLabel = createLabel(title: "4. Press 🤖 to signal the device to choose its symbol (randomly). Don't worry about your symbol. It can recognize it upto a 90.2% accuracy.", font: .systemFont(ofSize: 17, weight: .medium), alpha: 1.0, fontColor: .white, textAlignment: .left)
    var stepFiveLabel = createLabel(title: "5. First one to score 5 points wins!", font: .systemFont(ofSize: 17, weight: .medium), alpha: 1.0, fontColor: .white, textAlignment: .left)
    var stepSixLabel = createLabel(title: "6. Did you win? Go beyond in Impossible Mode! 🤘", font: .systemFont(ofSize: 17, weight: .medium), alpha: 1.0, fontColor: .white, textAlignment: .left)
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        titleLabel.frame = CGRect(x: 0, y: 0, width: self.view.frame.width, height: 70)
        stepOneLabel.frame = CGRect(x: 16, y: self.titleLabel.frame.maxY + 40, width: self.view.frame.width - 16, height: 50)
        stepTwoLabel.frame = CGRect(x: 16, y: self.stepOneLabel.frame.maxY + 10, width: self.view.frame.width - 16, height: 50)
        stepThreeLabel.frame = CGRect(x: 16, y: self.stepTwoLabel.frame.maxY + 10, width: self.view.frame.width - 16, height: 50)
        noteLabel.frame = CGRect(x: 16, y: self.stepThreeLabel.frame.maxY + 10, width: self.view.frame.width - 16, height: 90)
        stepFourLabel.frame = CGRect(x: 16, y: self.noteLabel.frame.maxY + 10, width: self.view.frame.width - 16, height: 70)
        stepFiveLabel.frame = CGRect(x: 16, y: self.stepFourLabel.frame.maxY + 10, width: self.view.frame.width - 16, height: 50)
        stepSixLabel.frame = CGRect(x: 16, y: self.stepFiveLabel.frame.maxY + 10, width: self.view.frame.width - 16, height: 50)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let gradient = createGradient(colors: [#colorLiteral(red: 0, green: 0.6470588235, blue: 1, alpha: 1).cgColor, #colorLiteral(red: 0, green: 0.2392156863, blue: 0.6745098039, alpha: 1).cgColor], startPoint: CGPoint(x: 1.0, y: 0.0), endPoint: CGPoint(x: 0.0, y: 1.0))
        gradient.frame = self.view.bounds
        self.view.layer.addSublayer(gradient)
        self.view.backgroundColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
        
        self.view.addSubview(titleLabel)
        self.view.addSubview(stepOneLabel)
        self.view.addSubview(stepTwoLabel)
        self.view.addSubview(noteLabel)
        self.view.addSubview(stepThreeLabel)
        self.view.addSubview(stepFourLabel)
        self.view.addSubview(stepFiveLabel)
        self.view.addSubview(stepSixLabel)
    }
}

class PageTwo: UIViewController {
    var titleLabel = createLabel(title: "Impossible Mode", font: UIFont.systemFont(ofSize: 40, weight: .bold), alpha: 1.0, fontColor: #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0), textAlignment: .center)
    var stepOneLabel = createLabel(title: "1. Welcome to Impossible Mode!", font: .systemFont(ofSize: 17, weight: .medium), alpha: 1.0, fontColor: .white, textAlignment: .left)
    var stepTwoLabel = createLabel(title: "2. Everything is similar as before... with a twist.", font: .systemFont(ofSize: 17, weight: .medium), alpha: 1.0, fontColor: .white, textAlignment: .left)
    var stepThreeLabel = createLabel(title: "3. Since machine learning can help recognize what you're holding, the device will generate a counterattack thus making it impossible to win.", font: .systemFont(ofSize: 17, weight: .medium), alpha: 1.0, fontColor: .white, textAlignment: .left)
    var stepFourLabel = createLabel(title: "4. As with most ML applications, the model is not perfect. But take your best shot!", font: .systemFont(ofSize: 17, weight: .medium), alpha: 1.0, fontColor: .white, textAlignment: .left)
    var stepFiveLabel = createLabel(title: "5. Want to see machine learning in action? Tap on 🤘 to activate Impossible Mode!", font: .systemFont(ofSize: 17, weight: .medium), alpha: 1.0, fontColor: .white, textAlignment: .left)
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        titleLabel.frame = CGRect(x: 0, y: 0, width: self.view.frame.width, height: 70)
        stepOneLabel.frame = CGRect(x: 16, y: self.titleLabel.frame.maxY + 40, width: self.view.frame.width - 16, height: 50)
        stepTwoLabel.frame = CGRect(x: 16, y: self.stepOneLabel.frame.maxY + 10, width: self.view.frame.width - 16, height: 50)
        stepThreeLabel.frame = CGRect(x: 16, y: self.stepTwoLabel.frame.maxY + 10, width: self.view.frame.width - 16, height: 70)
        stepFourLabel.frame = CGRect(x: 16, y: self.stepThreeLabel.frame.maxY + 10, width: self.view.frame.width - 16, height: 50)
        stepFiveLabel.frame = CGRect(x: 16, y: self.stepFourLabel.frame.maxY + 10, width: self.view.frame.width - 16, height: 50)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let gradient = createGradient(colors: [#colorLiteral(red: 0.556862771511078, green: 0.352941185235977, blue: 0.968627452850342, alpha: 1.0).cgColor, #colorLiteral(red: 0.219607844948769, green: 0.00784313771873713, blue: 0.854901969432831, alpha: 1.0).cgColor], startPoint: CGPoint(x: 1.0, y: 0.0), endPoint: CGPoint(x: 0.0, y: 1.0))
        gradient.frame = self.view.bounds
        self.view.layer.addSublayer(gradient)
        self.view.backgroundColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
        
        self.view.addSubview(titleLabel)
        self.view.addSubview(stepOneLabel)
        self.view.addSubview(stepTwoLabel)
        self.view.addSubview(stepThreeLabel)
        self.view.addSubview(stepFourLabel)
        self.view.addSubview(stepFiveLabel)
    }
}

class PageThree: UIViewController {
    let getStarted = createButton(title: "Let's Get Started", font: UIFont.systemFont(ofSize: 40, weight: .heavy), alpha: 1.0, fontColor: #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0), textAlignment: .center)
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        getStarted.frame = CGRect(x: 0, y: self.view.frame.midY - 25, width: self.view.frame.width, height: 50)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let gradient = createGradient(colors: [#colorLiteral(red: 0.941176474094391, green: 0.498039215803146, blue: 0.352941185235977, alpha: 1.0).cgColor, #colorLiteral(red: 0.925490200519562, green: 0.235294118523598, blue: 0.10196078568697, alpha: 1.0).cgColor], startPoint: CGPoint(x: 1.0, y: 0.0), endPoint: CGPoint(x: 0.0, y: 1.0))
        gradient.frame = self.view.bounds
        self.view.layer.addSublayer(gradient)
        getStarted.addTarget(self, action: #selector(self.startGame(sender:)), for: .touchUpInside)
        self.view.addSubview(getStarted)
    }
    
    @objc func startGame(sender: UIButton!) {
        dismiss(animated: true, completion: nil)
    }
}

class GameViewController: UIViewController, ARSCNViewDelegate, ARSessionDelegate {
    let session = ARSession()
    var sceneView = ARSCNView(frame: .zero)
    var closeButton = createButton(title: "👈", font: UIFont.systemFont(ofSize: 40), alpha: 0.0, fontColor: .white, textAlignment: .center)
    var analyzeButton = createButton(title: "🤖", font: UIFont.systemFont(ofSize: 50), alpha: 1.0, fontColor: .white, textAlignment: .center)
    var titleView = UIView(frame: .zero)
    var modeButton = createButton(title: "🤘", font: UIFont.systemFont(ofSize: 40), alpha: 0.0, fontColor: .white, textAlignment: .center)
    var gradient = createGradient(colors: [#colorLiteral(red: 0, green: 0.6470588235, blue: 1, alpha: 1).cgColor, #colorLiteral(red: 0, green: 0.2392156863, blue: 0.6745098039, alpha: 1).cgColor], startPoint: CGPoint(x: 1.0, y: 0.0), endPoint: CGPoint(x: 0.0, y: 1.0))
    var playerScoreLabel = createLabel(title: "YOU\n0", font: UIFont.systemFont(ofSize: 25, weight: .bold), alpha: 1.0, fontColor: .white, textAlignment: .center)
    var opponentScoreLabel = createLabel(title: "COMP\n0", font: UIFont.systemFont(ofSize: 25, weight: .bold), alpha: 1.0, fontColor: .white, textAlignment: .center)
    var commentaryLabel = createLabel(title: "Welcome to Normal Mode", font: .systemFont(ofSize: 20, weight: .medium), alpha: 1.0, fontColor: #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0), textAlignment: .center)
    let playerCylinder = SCNCylinder(radius: 0.05, height: 0.01)
    let computerCylinder = SCNCylinder(radius: 0.05, height: 0.01)
    let videoNode = SKVideoNode(fileNamed: "congrats.mp4")
    let skScene = SKScene(size: CGSize(width: 640, height: 450))
    let tvPlane = SCNPlane(width: 0.1, height: 0.075)
    let tvPlaneNode = SCNNode()
    
    var max: SCNNode?
    var translation = matrix_identity_float4x4
    var hasPlacedMax = false
    var playerScore = 0
    var computerScore = 0
    var impossibleModeOn = false
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        sceneView.frame = CGRect(x: 0.0, y: 0.0, width: self.view.frame.width, height: self.view.frame.height)
        playerScoreLabel.frame = CGRect(x: 8, y: 0, width: 80, height: 70)
        opponentScoreLabel.frame = CGRect(x: self.view.frame.maxX - 88, y: 0, width: 80, height: 70)
        closeButton.frame = CGRect(x: 16, y: self.view.frame.maxY - 100, width: 75, height: 75)
        analyzeButton.frame = CGRect(x: self.view.frame.midX - 50, y: self.view.frame.maxY - 125, width: 100, height: 100)
        titleView.frame = CGRect(x: 0, y: 0, width: self.view.frame.width, height: 70)
        gradient.frame = CGRect(x: 0, y: 0, width: self.view.frame.width, height: 70)
        modeButton.frame = CGRect(x: self.view.frame.maxX - 91, y: self.view.frame.maxY - 100, width: 75, height: 75)
        commentaryLabel.frame = CGRect(x: self.playerScoreLabel.frame.maxX, y: 0, width: self.opponentScoreLabel.frame.minX - self.playerScoreLabel.frame.maxX, height: 70)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        let vc = PageViewController()
        vc.modalPresentationStyle = .formSheet
        present(vc, animated: true, completion: nil)
    }
    
    override func loadView() {
        let scene = SCNScene()
        sceneView.scene = scene
        
        let configuration = ARWorldTrackingConfiguration()
        configuration.planeDetection = .horizontal
        sceneView.session.run(configuration)
        sceneView.delegate = self
        sceneView.setup()
        sceneView.session = session
        sceneView.showsStatistics = false
        sceneView.session.delegate = self
        sceneView.autoenablesDefaultLighting = true
        sceneView.automaticallyUpdatesLighting = true
        sceneView.scene = scene
        self.view = sceneView
        sceneView.session.run(configuration, options: [.resetTracking, .removeExistingAnchors])
    
        self.titleView.layer.addSublayer(gradient)
        self.view.addSubview(titleView)
        
        closeButton.backgroundColor = .white
        closeButton.layer.cornerRadius = 37.5
        closeButton.addTarget(self, action: #selector(self.closeView(sender:)), for: .touchUpInside)
        closeButton.isEnabled = false
        self.view.addSubview(closeButton)
        
        analyzeButton.backgroundColor = .white
        analyzeButton.layer.cornerRadius = 50
        analyzeButton.addTarget(self, action: #selector(self.analyzeGesture(sender:)), for: .touchUpInside)
        self.view.addSubview(analyzeButton)
        
        modeButton.backgroundColor = .white
        modeButton.layer.cornerRadius = 37.5
        modeButton.addTarget(self, action: #selector(self.changeMode(sender:)), for: .touchUpInside)
        modeButton.isEnabled = false
        self.view.addSubview(modeButton)
        
        playerScoreLabel.text = "YOU\n\(playerScore)"
        self.view.addSubview(playerScoreLabel)
        opponentScoreLabel.text = "COMP\n\(computerScore)"
        self.view.addSubview(opponentScoreLabel)
        self.view.addSubview(commentaryLabel)
    }
    
    func renderer(_ renderer: SCNSceneRenderer, didAdd node: SCNNode, for anchor: ARAnchor) {
        guard let planeAnchor = anchor as? ARPlaneAnchor else { return }
        let x = CGFloat(planeAnchor.center.x)
        let y = CGFloat(planeAnchor.center.y)
        let z = CGFloat(planeAnchor.center.z)
        
        playerCylinder.materials.first?.diffuse.contents = #colorLiteral(red: 0.239215686917305, green: 0.674509823322296, blue: 0.968627452850342, alpha: 1.0)
        let playerNode = SCNNode(geometry: playerCylinder)
        playerNode.position = SCNVector3(x,y,z)
        node.addChildNode(playerNode)
        
        computerCylinder.materials.first?.diffuse.contents = #colorLiteral(red: 0.364705890417099, green: 0.0666666701436043, blue: 0.968627452850342, alpha: 1.0)
        let computerNode = SCNNode(geometry: computerCylinder)
        computerNode.position = SCNVector3(x + 0.11,y,z)
        node.addChildNode(computerNode)
        
        tvPlaneNode.position = SCNVector3(x, y, z + 1.0)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        sceneView.session.pause()
    }
    
    @objc func closeView(sender: UIButton!) {
        dismiss(animated: true, completion: nil)
    }
    
    @objc func changeMode(sender: UIButton!) {
        let alertController = UIAlertController(title: "Impossible Mode", message: "Want to check out the power of ML? In Impossible Mode, your moves are always counterattacked. Care to try?", preferredStyle: .alert)
        let okAction = UIAlertAction(title: "I Got This!", style: .default, handler: { (alert) in
            UIView.animate(withDuration: 0.5, animations: { 
                self.gradient.colors = [#colorLiteral(red: 0.556862771511078, green: 0.352941185235977, blue: 0.968627452850342, alpha: 1.0).cgColor, #colorLiteral(red: 0.219607844948769, green: 0.00784313771873713, blue: 0.854901969432831, alpha: 1.0).cgColor]
            })
            if self.impossibleModeOn == false {
                self.playerScore = 0
                self.computerScore = 0
                self.playerCylinder.height = 0.01
                self.computerCylinder.height = 0.01
                self.updateScores()
            }
            self.impossibleModeOn = true
            self.commentaryLabel.text = "Welcome to Impossible Mode"
        })
        let nopeAction = UIAlertAction(title: "No Thank You!", style: .cancel, handler: { (alert) in
            UIView.animate(withDuration: 0.5, animations: { 
                self.gradient.colors = [#colorLiteral(red: 0, green: 0.6470588235, blue: 1, alpha: 1).cgColor, #colorLiteral(red: 0, green: 0.2392156863, blue: 0.6745098039, alpha: 1).cgColor]
            })
            if self.impossibleModeOn == true {
                self.playerScore = 0
                self.computerScore = 0
                self.playerCylinder.height = 0.01
                self.computerCylinder.height = 0.01
                self.updateScores()
            }
            self.impossibleModeOn = false
            self.commentaryLabel.text = "Welcome to Normal Mode"
        })
        alertController.addAction(okAction)
        alertController.addAction(nopeAction)
        
        alertController.view.tintColor = #colorLiteral(red: 0.556862771511078, green: 0.352941185235977, blue: 0.968627452850342, alpha: 1.0)
        self.present(alertController, animated: true, completion: nil)
    }
    
    @objc func analyzeGesture(sender: UIButton!) {
        if let indicator = self.sceneView.scene.rootNode.childNode(withName: "ARTV", recursively: true) {
            tvPlaneNode.removeFromParentNode()
        }
        self.analyzeButton.isEnabled = false
        self.analyzeButton.backgroundColor = .darkGray
        if let currentFrame = sceneView.session.currentFrame {
            DispatchQueue.global(qos: .background).async {
                do {
                    let model = try? VNCoreMLModel(for: RPS().model)
                    let request = VNCoreMLRequest(model: model!, completionHandler: { (request, error) in
                        DispatchQueue.main.async {
                            guard let results = request.results as? [VNClassificationObservation], let result = results.first else {
                                print("No results?")
                                return
                            }
                            if self.impossibleModeOn == true {
                                self.commentaryLabel.text = "Recognizing..."
                            } else {
                                self.commentaryLabel.text = "You chose \(result.identifier)!"
                            }
                            delay(1.0, completion: { 
                                if self.impossibleModeOn == false {
                                    self.commentaryLabel.text = "Randomly Selecting..."
                                } else if self.impossibleModeOn == true {
                                    self.commentaryLabel.text = "You chose \(result.identifier)!"
                                }
                                delay(1.0, completion: {
                                    if self.impossibleModeOn == false {
                                        self.randomChoice(forSelection: result.identifier)
                                    } else if self.impossibleModeOn == true {
                                        self.impossibleChoice(forSelection: result.identifier)
                                    }
                                })
                            })
                        }
                    })
                    let handler = VNImageRequestHandler(cvPixelBuffer: currentFrame.capturedImage, options: [:])
                    try handler.perform([request])
                } catch {}
            }
        }
    }
    
    func playCongratsVideo() {
        let vc = MenuViewController()
        vc.soundtrack?.volume = 0.0
        translation.columns.3.z = -0.15
        tvPlaneNode.geometry = tvPlane
        videoNode.play()
        skScene.addChild(videoNode)
        videoNode.position = CGPoint(x: skScene.size.width / 2, y: skScene.size.height / 2)
        videoNode.size = skScene.size
        tvPlane.firstMaterial?.diffuse.contents = skScene
        tvPlane.firstMaterial?.lightingModel = .constant
        tvPlane.firstMaterial?.isDoubleSided = true
        if let currentFrame = self.sceneView.session.currentFrame {
            tvPlaneNode.simdTransform = matrix_multiply((currentFrame.camera.transform), translation)
        } else {}
        tvPlaneNode.eulerAngles = SCNVector3(Double.pi,0,0)
        tvPlaneNode.name = "ARTV"
        self.sceneView.scene.rootNode.addChildNode(tvPlaneNode)
    }
    
    func updateScores() {
        playerScoreLabel.text = "\(playerScore)"
        opponentScoreLabel.text = "\(computerScore)"
        self.analyzeButton.isEnabled = true
        self.analyzeButton.backgroundColor = .white
        if playerScore == 5 {
            self.playCongratsVideo()
            self.analyzeButton.isEnabled = false
            self.analyzeButton.backgroundColor = .darkGray
            delay(1.0, completion: {
                self.commentaryLabel.text = "🎉 YOU WIN!!! 🎉"
            })
            delay(2.5, completion: {
                self.closeButton.isEnabled = true
                self.analyzeButton.isEnabled = true
                self.modeButton.isEnabled = true
                self.commentaryLabel.text = "I call a rematch!"
                UIView.animate(withDuration: 0.5, animations: {
                    self.closeButton.alpha = 1.0
                    self.modeButton.alpha = 1.0
                    self.analyzeButton.backgroundColor = .white
                    self.playerScore = 0
                    self.computerScore = 0
                    self.playerCylinder.height = 0.01
                    self.computerCylinder.height = 0.01
                })
                self.updateScores()
            })
        } else if computerScore == 5 {
            self.analyzeButton.isEnabled = false
            self.analyzeButton.backgroundColor = .darkGray
            delay(1.0, completion: {
                self.commentaryLabel.text = "🎉 I WIN!!! 🎉"
            })
            delay(2.0, completion: {
                self.closeButton.isEnabled = true
                self.modeButton.isEnabled = true
                self.analyzeButton.isEnabled = true
                self.commentaryLabel.text = "Let's Play Again!"
                UIView.animate(withDuration: 0.5, animations: {
                    self.closeButton.alpha = 1.0
                    self.modeButton.alpha = 1.0
                    self.analyzeButton.backgroundColor = .white
                    self.playerScore = 0
                    self.computerScore = 0
                    self.playerCylinder.height = 0.01
                    self.computerCylinder.height = 0.01
                })
                self.updateScores()
            })
        }
    }
    
    func randomChoice(forSelection: String) {
        let choices = ["✌️", "✊", "🖐"]
        var item = 0
        let popUpTimer = Timer.scheduledTimer(withTimeInterval: 0.1, repeats: true, block: { timer in
            self.commentaryLabel.text = choices.random()
            item += 1
            if item >= 20 {
                timer.invalidate()
                let selection = self.commentaryLabel.text
                self.commentaryLabel.text = "I choose \(selection!)!"
                delay(1.0, completion: {
                    if selection == "✊" {
                        if forSelection == "Rock" {
                            self.commentaryLabel.text = "TIE"
                            self.updateScores()
                        } else if forSelection == "Paper" {
                            self.commentaryLabel.text = "You Get A Point!"
                            self.playerScore += 1
                            self.playerCylinder.height += 0.02
                            self.updateScores()
                        } else if forSelection == "Scissors" {
                            self.commentaryLabel.text = "I Get A Point!"
                            self.computerScore += 1
                            self.computerCylinder.height += 0.02
                            self.updateScores()
                        }
                    } else if selection == "🖐" {
                        if forSelection == "Rock" {
                            self.commentaryLabel.text = "I Get A Point!"
                            self.computerScore += 1
                            self.computerCylinder.height += 0.02
                            self.updateScores()
                        } else if forSelection == "Paper" {
                            self.commentaryLabel.text = "TIE"
                            self.updateScores()
                        } else if forSelection == "Scissors" {
                            self.commentaryLabel.text = "You Get A Point!"
                            self.playerScore += 1
                            self.playerCylinder.height += 0.02
                            self.updateScores()
                        }
                    } else if selection == "✌️" {
                        if forSelection == "Rock" {
                            self.commentaryLabel.text = "You Get A Point!"
                            self.playerCylinder.height += 0.02
                            self.playerScore += 1
                            self.updateScores()
                        } else if forSelection == "Paper" {
                            self.commentaryLabel.text = "I Get A Point!"
                            self.computerCylinder.height += 0.02
                            self.computerScore += 1
                            self.updateScores()
                        } else if forSelection == "Scissors" {
                            self.commentaryLabel.text = "TIE"
                            self.updateScores()
                        }
                    }
                })
            }
        })
    }
    
    func impossibleChoice(forSelection: String) {
        delay(0.2, completion: {
            if forSelection == "Rock" {
                self.commentaryLabel.text = "I choose 🖐"
                self.computerScore += 1
                self.computerCylinder.height += 0.02
                self.updateScores()
            } else if forSelection == "Paper" {
                self.commentaryLabel.text = "I choose ✌️"
                self.computerScore += 1
                self.computerCylinder.height += 0.02
                self.updateScores()
            } else if forSelection == "Scissors" {
                self.commentaryLabel.text = "I choose ✊"
                self.computerScore += 1
                self.computerCylinder.height += 0.02
                self.updateScores()
            }
        })
    }
}


class DevViewController: UIViewController {
    var imageView = UIImageView(frame: .zero)
    var titleView = UIVisualEffectView(effect: UIBlurEffect(style: .dark))
    var closeButton = UIButton(frame: .zero)
    var textView = UIVisualEffectView(effect: UIBlurEffect(style: .extraLight))
    var vcTitle = UILabel(frame: .zero)
    var desc = UILabel(frame: .zero)
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        imageView.frame = CGRect(x: 0, y: 0, width: self.view.frame.width, height: self.view.frame.height)
        titleView.frame = CGRect(x: 0, y: 0, width: self.view.bounds.width, height: 70)
        vcTitle.frame = CGRect(x: self.view.frame.midX - 150, y: 5, width: 300, height: 60)
        closeButton.frame = CGRect(x: 3, y: 15, width: 40, height: 40)
        textView.frame = CGRect(x: 20, y: self.view.frame.maxY * 0.73, width: self.view.frame.maxX - 40, height: 150)
        desc.frame = CGRect(x: 30, y: self.textView.frame.minY + 15, width: textView.frame.width - 20, height: self.textView.frame.height - 30)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        imageView.contentMode = .scaleAspectFill
        imageView.clipsToBounds = true
        imageView.image = #imageLiteral(resourceName: "me.JPG")
        imageView.center = view.center
        view.addSubview(imageView)
        self.view.sendSubview(toBack: imageView)
        
        self.view.addSubview(titleView)
        
        closeButton.setImage(#imageLiteral(resourceName: "closeIcon.png"), for: .normal)
        closeButton.addTarget(self, action: #selector(self.closeView(sender:)), for: .touchUpInside)
        closeButton.showsTouchWhenHighlighted = true
        closeButton.tintColor = .white
        self.view.addSubview(closeButton)
        
        textView.layer.masksToBounds = true
        textView.layer.cornerRadius = 15
        textView.alpha = 0
        self.view.addSubview(textView)
        
        vcTitle.textAlignment = .center
        vcTitle.text = "About The Developer"
        vcTitle.font = UIFont.systemFont(ofSize: 30, weight: .bold)
        vcTitle.textColor = .white
        self.view.addSubview(vcTitle)
        
        desc.textAlignment = .center
        desc.numberOfLines = 0
        desc.alpha = 0
        desc.text = "Hello! My name is Sai Kambampati. I am 16 years old and a HUGE fan of technology, especially machine learning! After seeing all the amazing people at WWDC 2017, I wanted to expand my horizons. Now, I write tutorials on AppCoda and blog on Medium. WWDC 2018 would be an amazing opportunity for me to continue to spread my love as well as learn more from amazing engineers and developers. Hope you enjoy my playground!"
        desc.font = UIFont.systemFont(ofSize: 14, weight: .light)
        desc.textColor = .black
        self.view.addSubview(desc)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(true)
        UIView.animate(withDuration: 0.5, delay: 0.5, animations: { 
            self.textView.frame = self.textView.frame.offsetBy(dx: 0, dy: -30)
            self.desc.frame = self.desc.frame.offsetBy(dx: 0, dy: -30)
            self.desc.alpha = 1
            self.textView.alpha = 1
        })
    }
    
    @objc func closeView(sender: UIButton!) {
        dismiss(animated: true, completion: nil)
    }
}


class PlaygroundViewController: UIViewController {
    var imageView = UIImageView(frame: .zero)
    var titleView = UIVisualEffectView(effect: UIBlurEffect(style: .dark))
    var closeButton = UIButton(frame: .zero)
    var textView = UIVisualEffectView(effect: UIBlurEffect(style: .extraLight))
    var vcTitle = UILabel(frame: .zero)
    var desc = UILabel(frame: .zero)
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        titleView.frame = CGRect(x: 0, y: 0, width: self.view.bounds.width, height: 70)
        vcTitle.frame = CGRect(x: self.view.frame.midX - 175, y: 5, width: 350, height: 60)
        closeButton.frame = CGRect(x: 3, y: 15, width: 40, height: 40)
        textView.frame = CGRect(x: 20, y: self.view.frame.maxY * 0.73, width: self.view.frame.maxX - 40, height: 150)
        desc.frame = CGRect(x: 30, y: self.textView.frame.minY + 15, width: textView.frame.width - 20, height: self.textView.frame.height - 30)
        imageView.frame = CGRect(x: 0, y: 0, width: self.view.frame.width, height: self.view.frame.height)
    }
    
    override public func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        imageView.contentMode = .scaleAspectFill
        imageView.clipsToBounds = true
        imageView.image = #imageLiteral(resourceName: "2017Kits.png")
        imageView.center = view.center
        view.addSubview(imageView)
        self.view.addSubview(imageView)
        
        self.view.addSubview(titleView)
        
        closeButton.setImage(#imageLiteral(resourceName: "closeIcon.png"), for: .normal)
        closeButton.showsTouchWhenHighlighted = true
        closeButton.addTarget(self, action: #selector(self.closeView(sender:)), for: .touchUpInside)
        closeButton.tintColor = .white
        self.view.addSubview(closeButton)
        
        textView.layer.masksToBounds = true
        textView.layer.cornerRadius = 15
        textView.alpha = 0
        self.view.addSubview(textView)
        
        vcTitle.textAlignment = .center
        vcTitle.text = "Beyond The Code"
        vcTitle.font = UIFont.systemFont(ofSize: 30, weight: .bold)
        vcTitle.textColor = .white
        self.view.addSubview(vcTitle)
        
        desc.textAlignment = .center
        desc.numberOfLines = 0
        desc.alpha = 0
        desc.text = "Even before I had an idea for my playground, I resolved on one goal: that everything should be made by me. I'm excited to say that I was able to achieve this. The images were taken by me, created using Sketch, or drawn using  Pencil. I composed the music using GarageBand & even made the CoreML model from scratch. Initially, I was a beginner to ARKit but I learned a lot through the playground's creation and was able to implement it!"
        desc.font = UIFont.systemFont(ofSize: 14, weight: .light)
        desc.textColor = .black
        self.view.addSubview(desc)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(true)
        UIView.animate(withDuration: 0.5, delay: 0.5, animations: { 
            self.textView.frame = self.textView.frame.offsetBy(dx: 0, dy: -30)
            self.desc.frame = self.desc.frame.offsetBy(dx: 0, dy: -30)
            self.desc.alpha = 1
            self.textView.alpha = 1
        })
    }
    
    @objc func closeView(sender: UIButton!) {
        dismiss(animated: true, completion: nil)
    }
}

class AcknowledgementsViewController: UIViewController {
    var imageView = UIImageView(frame: .zero)
    var titleView = UIVisualEffectView(effect: UIBlurEffect(style: .dark))
    var closeButton = UIButton(frame: .zero)
    var vcTitle = UILabel(frame: .zero)
    var desc = UILabel(frame: .zero)
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        imageView.frame = CGRect(x: 0, y: 0, width: self.view.frame.width, height: self.view.frame.height)
        titleView.frame = CGRect(x: 0, y: 0, width: self.view.bounds.width, height: 70)
        vcTitle.frame = CGRect(x: self.view.frame.midX - 150, y: 5, width: 300, height: 60)
        closeButton.frame = CGRect(x: 3, y: 15, width: 40, height: 40)
        desc.frame = CGRect(x: 30, y: (self.view.frame.maxY * 0.73) + 15, width: self.view.frame.maxX - 60, height: 120)
    }
    
    override public func viewDidLoad() {
        super.viewDidLoad()
        let background = #imageLiteral(resourceName: "Apples.png")
        imageView.contentMode = .scaleAspectFill
        imageView.clipsToBounds = true
        imageView.image = background
        imageView.center = view.center
        view.addSubview(imageView)
        self.view.sendSubview(toBack: imageView)
        
        self.view.addSubview(titleView)
        
        closeButton.setImage(#imageLiteral(resourceName: "closeIcon.png"), for: .normal)
        closeButton.addTarget(self, action: #selector(self.closeView(sender:)), for: .touchUpInside)
        closeButton.showsTouchWhenHighlighted = true
        closeButton.tintColor = .white
        self.view.addSubview(closeButton)
        
        vcTitle.textAlignment = .center
        vcTitle.text = "Acknowledgements"
        vcTitle.font = UIFont.systemFont(ofSize: 30, weight: .bold)
        vcTitle.textColor = .white
        self.view.addSubview(vcTitle)
        
        desc.textAlignment = .center
        desc.numberOfLines = 0
        desc.alpha = 0
        desc.text = "First, I want to thank my family for encouraging my passion for coding. Next, I want to thank all the amazing people at Apple, from the super smart engineers to the judges reading this right now to the people working hard on preparing for WWDC, for giving me this opportunity to showcase my talents! Finally, I want to thank all the people creating new tech for always inspiring me to develop magical tech for the world!"
        desc.font = UIFont.systemFont(ofSize: 14, weight: .light)
        desc.textColor = .black
        self.view.addSubview(desc)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(true)
        UIView.animate(withDuration: 0.5, delay: 0.5, animations: {
            self.desc.frame = self.desc.frame.offsetBy(dx: 0, dy: -30)
            self.desc.alpha = 1
        })
    }
    
    @objc func closeView(sender: UIButton!) {
        dismiss(animated: true, completion: nil)
    }
}

class FutureViewController: UIViewController {
    var imageView = UIImageView(frame: .zero)
    var titleView = UIVisualEffectView(effect: UIBlurEffect(style: .dark))
    var closeButton = UIButton(frame: .zero)
    var textView = UIVisualEffectView(effect: UIBlurEffect(style: .extraLight))
    var vcTitle = UILabel(frame: .zero)
    var desc = UILabel(frame: .zero)
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        imageView.frame = CGRect(x: 0, y: 0, width: self.view.frame.width, height: self.view.frame.height)
        titleView.frame = CGRect(x: 0, y: 0, width: self.view.bounds.width, height: 70)
        vcTitle.frame = CGRect(x: self.view.frame.midX - 150, y: 5, width: 300, height: 60)
        closeButton.frame = CGRect(x: 3, y: 15, width: 40, height: 40)
        textView.frame = CGRect(x: 20, y: self.view.frame.maxY * 0.73, width: self.view.frame.maxX - 40, height: 150)
        desc.frame = CGRect(x: 30, y: self.textView.frame.minY + 15, width: textView.frame.width - 20, height: self.textView.frame.height - 30)
    }
    
    override public func viewDidLoad() {
        super.viewDidLoad()
        let background = #imageLiteral(resourceName: "thoughtfulMe.jpg")
        imageView.contentMode = .scaleAspectFill
        imageView.clipsToBounds = true
        imageView.image = background
        imageView.center = view.center
        view.addSubview(imageView)
        self.view.sendSubview(toBack: imageView)
        
        textView.layer.masksToBounds = true
        textView.layer.cornerRadius = 15
        textView.alpha = 0
        self.view.addSubview(textView)
        
        self.view.addSubview(titleView)
        
        closeButton.setImage(#imageLiteral(resourceName: "closeIcon.png"), for: .normal)
        closeButton.addTarget(self, action: #selector(self.closeView(sender:)), for: .touchUpInside)
        closeButton.showsTouchWhenHighlighted = true
        closeButton.tintColor = .white
        self.view.addSubview(closeButton)
        
        vcTitle.textAlignment = .center
        vcTitle.text = "The A Games"
        vcTitle.font = UIFont.systemFont(ofSize: 30, weight: .bold)
        vcTitle.textColor = .white
        self.view.addSubview(vcTitle)
        
        desc.textAlignment = .center
        desc.numberOfLines = 0
        desc.alpha = 0
        desc.text = "During the creation of this playground, I was only focused on completing it. Now that I have time to reflect, I'm wondering how many more games like this I can take and transform into something new and wonderful with the help of AI and AR. It would require lots of images and all but I really think that this game could start a new trend withing the industry. I would call it: The A Games! Pretty pumped about this venture!"
        desc.font = UIFont.systemFont(ofSize: 14, weight: .light)
        desc.textColor = .black
        self.view.addSubview(desc)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(true)
        UIView.animate(withDuration: 0.5, delay: 0.5, animations: {
            self.textView.frame = self.textView.frame.offsetBy(dx: 0, dy: -30)
            self.desc.frame = self.desc.frame.offsetBy(dx: 0, dy: -30)
            self.desc.alpha = 1
            self.textView.alpha = 1
        })
    }
    
    @objc func closeView(sender: UIButton!) {
        dismiss(animated: true, completion: nil)
    }
}

/// Model Prediction Input Type
@available(macOS 10.13, iOS 11.0, tvOS 11.0, watchOS 4.0, *)
class RPSInput : MLFeatureProvider {
    
    /// data as color (kCVPixelFormatType_32BGRA) image buffer, 227 pixels wide by 227 pixels high
    var data: CVPixelBuffer
    
    var featureNames: Set<String> {
        get {
            return ["data"]
        }
    }
    
    func featureValue(for featureName: String) -> MLFeatureValue? {
        if (featureName == "data") {
            return MLFeatureValue(pixelBuffer: data)
        }
        return nil
    }
    
    init(data: CVPixelBuffer) {
        self.data = data
    }
}


/// Model Prediction Output Type
@available(macOS 10.13, iOS 11.0, tvOS 11.0, watchOS 4.0, *)
class RPSOutput : MLFeatureProvider {
    
    /// loss as dictionary of strings to doubles
    let loss: [String : Double]
    
    /// classLabel as string value
    let classLabel: String
    
    var featureNames: Set<String> {
        get {
            return ["loss", "classLabel"]
        }
    }
    
    func featureValue(for featureName: String) -> MLFeatureValue? {
        if (featureName == "loss") {
            return try! MLFeatureValue(dictionary: loss as [NSObject : NSNumber])
        }
        if (featureName == "classLabel") {
            return MLFeatureValue(string: classLabel)
        }
        return nil
    }
    
    init(loss: [String : Double], classLabel: String) {
        self.loss = loss
        self.classLabel = classLabel
    }
}


/// Class for model loading and prediction
@available(macOS 10.13, iOS 11.0, tvOS 11.0, watchOS 4.0, *)
class RPS {
    var model: MLModel
    
    /**
     Construct a model with explicit path to mlmodel file
     - parameters:
     - url: the file url of the model
     - throws: an NSError object that describes the problem
     */
    init(contentsOf url: URL) throws {
        self.model = try MLModel(contentsOf: url)
    }
    
    /// Construct a model that automatically loads the model from the app's bundle
    convenience init() {
        let bundle = Bundle(for: RPS.self)
        let assetPath = bundle.url(forResource: "RPS", withExtension:"mlmodelc")
        try! self.init(contentsOf: assetPath!)
    }
    
    /**
     Make a prediction using the structured interface
     - parameters:
     - input: the input to the prediction as RPSInput
     - throws: an NSError object that describes the problem
     - returns: the result of the prediction as RPSOutput
     */
    func prediction(input: RPSInput) throws -> RPSOutput {
        let outFeatures = try model.prediction(from: input)
        let result = RPSOutput(loss: outFeatures.featureValue(for: "loss")!.dictionaryValue as! [String : Double], classLabel: outFeatures.featureValue(for: "classLabel")!.stringValue)
        return result
    }
    
    /**
     Make a prediction using the convenience interface
     - parameters:
     - data as color (kCVPixelFormatType_32BGRA) image buffer, 227 pixels wide by 227 pixels high
     - throws: an NSError object that describes the problem
     - returns: the result of the prediction as RPSOutput
     */
    func prediction(data: CVPixelBuffer) throws -> RPSOutput {
        let input_ = RPSInput(data: data)
        return try self.prediction(input: input_)
    }
}

extension ARSCNView {
    func setup() {
        antialiasingMode = .multisampling4X
        automaticallyUpdatesLighting = false
        
        preferredFramesPerSecond = 60
        contentScaleFactor = 1.0
        
        if let camera = pointOfView?.camera {
            camera.wantsHDR = true
            camera.wantsExposureAdaptation = true
            camera.exposureOffset = 0
            camera.minimumExposure = 0
            camera.maximumExposure = 2
            camera.focusDistance = 0.5
        }
    }
}

extension Array  
{
    func random() -> Element  
    {
        return self[Int(arc4random_uniform(UInt32(self.count)))]  
    }
}

PlaygroundPage.current.liveView = MenuViewController()
